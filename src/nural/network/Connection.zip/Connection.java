package nural.network;

public class Connection {

}
